#!/bin/bash

git fetch --all

git pull origin bahmniapps_92build
