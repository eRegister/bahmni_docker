#!/bin/bash

git fetch --all

git pull origin registrationcore_build
