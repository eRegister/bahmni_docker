#!/bin/bash

git fetch --all

git pull origin bahmnicore_92_build
