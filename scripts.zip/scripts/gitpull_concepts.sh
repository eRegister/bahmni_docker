#!/bin/bash

git fetch --all

git pull origin master
