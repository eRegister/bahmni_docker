#!/bin/bash

sudo git fetch --all
sudo git pull origin master
