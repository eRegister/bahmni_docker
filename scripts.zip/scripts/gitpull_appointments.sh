#!/bin/bash

git fetch --all

git pull origin appointments_92_build
